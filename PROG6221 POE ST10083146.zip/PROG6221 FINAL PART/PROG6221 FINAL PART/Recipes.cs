﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG6221_FINAL_PART
{
    class Recipes
    {
       public string recipes { get; set; }
        public string[] foodgroup { get; set; }
        public int[] calories { get; set; }
        public string[] ingredients { get; set; }
    }
}
