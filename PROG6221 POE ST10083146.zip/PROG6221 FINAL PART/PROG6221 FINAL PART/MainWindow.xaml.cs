﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace PROG6221_FINAL_PART
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public List<Recipes> RecipesList { get; set; }
        public string[] foodgroup { get; set; }
        public int[] calories { get; set; }
        public string[] ingredients { get; set; }
        public MainWindow()
        {
        InitializeComponent();
            RecipesList = new List<Recipes>
            {
            Recipes recipes = new Recipes();
            foodgroup = new string[] { "FoodGroup1", "FoodGroup2", "FoodGroup3" };
            calories = new int[] {500, 800, 600};
            ingredients = new string[] { "RecipeA", "RecipeB", "RecipeC" };

            

            DataContext = this;
        }
        private void Calories_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void button_Click(object sender, RoutedEventArgs e)
        {


        }

        private void button_Click_1(object sender, RoutedEventArgs e)
        {
         
            
        }

        private void Ingredients_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Calories_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void AddBtn_Click(object sender, RoutedEventArgs e)
        {
            Ingredients.Items.Clear();
            Ingredients.Items.Add("RecipeA");
            Ingredients.Items.Add("RecipeB");
            Ingredients.Items.Add("RecipeC");
            Ingredients.Text = "Select from...";
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            Calories.Items.Clear();
            Calories.Items.Add(500);
            Calories.Items.Add(600);
            Calories.Items.Add(800);
            Calories.Text = "Select from...";
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            FoodGroup.Items.Clear();
            FoodGroup.Items.Add("FoodGroup1");
            FoodGroup.Items.Add("FoodGroup2");
            FoodGroup.Items.Add("FoodGroup3");
            FoodGroup.Text = "Select from...";
        }
    }
}
